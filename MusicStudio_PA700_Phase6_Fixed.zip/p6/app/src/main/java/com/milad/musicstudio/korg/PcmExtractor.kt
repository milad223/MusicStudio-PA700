package com.milad.musicstudio.korg

import java.io.File
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

 data class PcmRecord(
    val index:Int,val headerOffset:Long,val dataOffset:Long,val dataEnd:Long,
    val sampleCount:Long,val loopStart:Long,val loopEnd:Long,val rateField:Long,
    val payloadBytes:Long,val compressedCandidate:Boolean,
    val f20:Long,val f24:Long,val f60:Long,val f64:Long,val probe:String)

object PcmExtractor {
 private val MARKER=byteArrayOf(0x12,0,0,0x18)
 private val KEND=byteArrayOf('K'.code.toByte(),'E'.code.toByte(),'N'.code.toByte(),'D'.code.toByte())
 fun hasKorf(f:File)=indexOf(f.readBytes(),byteArrayOf('K'.code.toByte(),'O'.code.toByte(),'R'.code.toByte(),'F'.code.toByte()),0)>=0
 fun hasKend(f:File)=indexOf(f.readBytes(),KEND,0)>=0
 fun scan(file:File):List<PcmRecord>{
  val a=file.readBytes(); val marks=mutableListOf<Int>(); var p=0
  while(true){val x=indexOf(a,MARKER,p);if(x<0)break;marks+=x;p=x+4}
  val kend=indexOf(a,KEND,maxOf(0,a.size-65536)); val out=mutableListOf<PcmRecord>()
  for(i in marks.indices){
   val h=marks[i]; val end=if(i+1<marks.size)marks[i+1] else if(kend>=0)kend else a.size
   if(h+76>end)continue
   val data=h+76; val payload=(end-data).toLong()
   val f20=u32(a,h+20); val f24=u32(a,h+24); val f60=u32(a,h+60); val f64=u32(a,h+64)
   val expected16=f24*2
   out+=PcmRecord(i,h.toLong(),data.toLong(),end.toLong(),f24,f60,f64,f20,payload,payload!=expected16,f20,f24,f60,f64,probe(a,data,end))
  }
  return out
 }
 private fun probe(a:ByteArray,s:Int,e:Int):String{
  val n=minOf((e-s)/2,12000); if(n<100)return "too-small"
  var max=0; var mean=0.0; var z=0; var prev=0
  for(i in 0 until n){ val v=ByteBuffer.wrap(a,s+i*2,2).order(ByteOrder.LITTLE_ENDIAN).short.toInt(); max=maxOf(max,abs(v)); mean+=v; if(i>0 && ((prev<0)!=(v<0)))z++; prev=v }
  mean/=n
  val rms=kotlin.math.sqrt((0 until n).sumOf{val v=ByteBuffer.wrap(a,s+it*2,2).order(ByteOrder.LITTLE_ENDIAN).short.toDouble();v*v}/n)
  return "raw16LE max=$max rms=${"%.0f".format(rms)} mean=${"%.0f".format(mean)} zc=$z"
 }
 fun exportExperimentalWav(file:File,r:PcmRecord,rate:Int):File{
  val a=file.readBytes(); val start=r.dataOffset.toInt(); val end=r.dataEnd.toInt(); val raw=a.copyOfRange(start,end); val out=File(file.parentFile,"${file.nameWithoutExtension}_record${r.index}_raw16le.wav")
  val h=ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
  h.put("RIFF".toByteArray()); h.putInt(36+raw.size); h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1); h.putInt(rate); h.putInt(rate*2); h.putShort(2); h.putShort(16); h.put("data".toByteArray()); h.putInt(raw.size)
  out.outputStream().use{it.write(h.array());it.write(raw)}; return out
 }
 private fun u32(a:ByteArray,o:Int)=ByteBuffer.wrap(a,o,4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
 private fun indexOf(a:ByteArray,p:ByteArray,start:Int):Int{if(start<0)return -1;for(i in start..a.size-p.size){var ok=true;for(j in p.indices)if(a[i+j]!=p[j]){ok=false;break};if(ok)return i};return -1}
}
