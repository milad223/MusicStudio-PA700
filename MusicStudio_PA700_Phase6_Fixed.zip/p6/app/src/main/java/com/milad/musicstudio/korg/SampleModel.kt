package com.milad.musicstudio.korg

data class SampleData(val pcm: ShortArray, val sampleRate: Int, val channels: Int = 1)
data class DecoderResult(val sample: SampleData?, val confidence: String, val message: String)
