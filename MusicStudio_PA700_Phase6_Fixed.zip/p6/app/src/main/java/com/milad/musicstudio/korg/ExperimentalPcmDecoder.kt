package com.milad.musicstudio.korg

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Conservative decoder: only exposes a sample when the payload is plausibly signed 16-bit PCM.
 * It deliberately does NOT claim to decode KORG compressed data.
 */
object ExperimentalPcmDecoder {
    fun decode(file: File, record: PcmRecord, sampleRate: Int = 44100): DecoderResult {
        val bytes = file.inputStream().use { it.skipFully(record.dataOffset); it.readNBytes(record.payloadBytes.toInt()) }
        if (bytes.size < 4 || bytes.size % 2 != 0) return DecoderResult(null, "none", "payload is not a valid raw16 candidate")
        val pcm = ShortArray(bytes.size / 2)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var max = 0
        for (i in pcm.indices) { pcm[i] = bb.short; max = maxOf(max, kotlin.math.abs(pcm[i].toInt())) }
        if (max < 32) return DecoderResult(null, "low", "payload looks silent/encoded")
        return DecoderResult(SampleData(pcm, sampleRate), "experimental", "raw16 little-endian interpretation only")
    }

    private fun java.io.InputStream.skipFully(n: Long): Long {
        var left = n
        while (left > 0) { val s = skip(left); if (s <= 0) { if (read() < 0) break else left-- } else left -= s }
        return n-left
    }
}
