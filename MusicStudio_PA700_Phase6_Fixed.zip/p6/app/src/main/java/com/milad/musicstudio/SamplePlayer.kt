package com.milad.musicstudio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.milad.musicstudio.korg.SampleData

class SamplePlayer {
    private var track: AudioTrack? = null
    fun play(sample: SampleData) {
        stop()
        val mask = if (sample.channels == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val min = AudioTrack.getMinBufferSize(sample.sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sample.sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
            .setBufferSizeInBytes(maxOf(min, sample.pcm.size * 2))
            .setTransferMode(AudioTrack.MODE_STATIC).build()
        track!!.write(sample.pcm, 0, sample.pcm.size, AudioTrack.WRITE_BLOCKING)
        track!!.play()
    }
    fun stop() { track?.let { runCatching { it.stop() }; it.release() }; track = null }
}
