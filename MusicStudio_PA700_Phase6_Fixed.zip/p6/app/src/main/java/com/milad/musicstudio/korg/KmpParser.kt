package com.milad.musicstudio.korg

import java.io.File

data class KmpZone(val index:Int, val offset:Long, val low:Int?, val high:Int?, val root:Int?, val velocityLow:Int?, val velocityHigh:Int?, val name:String?)
data class KmpReport(val signature:Boolean, val size:Long, val names:List<String>, val zones:List<KmpZone>, val notes:List<String>)

/** Heuristic KMP inspector. It reports observable fields/candidates and deliberately
 * does not label guessed byte offsets as an authoritative KORG specification. */
object KmpParser {
    fun inspect(file: File): KmpReport {
        val a=file.readBytes()
        val korf = indexOf(a, byteArrayOf(0x4b,0x4f,0x52,0x46)) >= 0
        val names=mutableListOf<String>()
        var i=0
        while(i<a.size){
            if(a[i].toInt()==0x1c){
                var j=i+1
                while(j<a.size && j<i+65 && a[j].toInt() in 32..126) j++
                if(j-i>=5){
                    val s=String(a,i+1,j-i-1).trim().replace("\\u0000","")
                    if(s.length>=4 && s !in names) names+=s
                }
                i=j
            } else i++
        }
        // The KMP sample shown by the project contains repeated 0x2d 0x01 0x8a ...
        // structures. We expose byte-derived candidates only when they fit MIDI ranges.
        val zones=mutableListOf<KmpZone>()
        val marker=byteArrayOf(0x2d,0x01,0x8a.toByte())
        var p=0; var z=0
        while(true){
            val m=indexOf(a,marker,p); if(m<0) break
            val low = if(m+7<a.size) a[m+5].toInt() and 0xff else null
            val high = if(m+8<a.size) a[m+6].toInt() and 0xff else null
            val root = if(m+9<a.size) a[m+7].toInt() and 0xff else null
            if(low!=null && high!=null && root!=null && low<=127 && high<=127 && root<=127)
                zones+=KmpZone(z++,m.toLong(),low,high,root,null,null,null)
            p=m+marker.size
        }
        val notes=mutableListOf<String>()
        notes += "KORF signature: $korf"
        notes += "Printable-name extraction: ${names.size} candidates"
        notes += "Zone candidates: ${zones.size}"
        notes += "Key/velocity fields are candidates until validated against multiple KMP files."
        return KmpReport(korf,a.size.toLong(),names.take(80),zones.take(256),notes)
    }
    private fun indexOf(a:ByteArray,p:ByteArray,start:Int=0):Int {
        if(p.isEmpty()) return start
        outer@ for(i in start..a.size-p.size){ for(j in p.indices) if(a[i+j]!=p[j]) continue@outer; return i }
        return -1
    }
}
