# Music Studio PA700 - Phase 6

Android project for the independent PA700 compatibility engine.

## GitHub Actions

The repository includes `.github/workflows/android.yml` and deliberately does **not** require a checked-in Gradle wrapper. GitHub Actions installs Gradle 8.7 and uses JDK 17.

Important: the repository root must contain `settings.gradle.kts`, `build.gradle.kts`, and `app/`. Do not run Gradle from a parent directory that only contains this project folder.

## Local build

From this directory:

```bash
gradle :app:assembleDebug
```

## Current scope

Phase 6 focuses on connecting KMP mapping to PCM/sample playback infrastructure. KORG proprietary compression is not claimed to be fully decoded yet.
