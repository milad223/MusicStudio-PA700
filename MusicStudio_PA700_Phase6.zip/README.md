# Music Studio PA700 — Phase 6

## KMP → PCM → Keyboard bridge

This phase turns the Phase 5 structural mapping into an executable compatibility path:

1. Parse a KMP file into zones.
2. Scan a PCM container for observed records.
3. Conservatively decode records only when they look like raw little-endian 16-bit PCM.
4. Bind KMP zones to PCM records by sample reference when possible, otherwise use an explicitly labelled fallback.
5. On a key press, select the matching zone/record and resample the decoded sample from Root Key to the requested MIDI note.
6. Play the resulting sample through Android `AudioTrack`.

### Important compatibility boundary

The project does **not** claim that the proprietary KORG sample compression has been decoded. Any record that does not pass the conservative raw16LE probe is reported as not decoded. The fallback binding is for engineering validation and is not a claim about the exact KMP specification.

### Build

Android Studio / Gradle project. `compileSdk 35`, minSdk 26, Kotlin 2.0.21, AGP 8.5.2.

### Test flow

- Load a KMP file and press **Parse KMP**.
- Load a PCM container and press **Bind PCM**.
- The report shows zone → PCM record bindings and which records decoded.
- Press a keyboard key. If a decoded sample is bound to its zone, it is pitch-shifted from Root Key and played; otherwise the app falls back to the internal test tone.
