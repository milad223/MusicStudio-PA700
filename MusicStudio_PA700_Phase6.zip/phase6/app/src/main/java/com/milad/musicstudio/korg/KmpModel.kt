package com.milad.musicstudio.korg

data class KeyZone(
    val lowKey: Int,
    val highKey: Int,
    val rootKey: Int,
    val velocityLow: Int = 1,
    val velocityHigh: Int = 127,
    val sampleRef: Int? = null,
    val confidence: String = "heuristic"
)

data class KmpProgram(
    val name: String,
    val zones: List<KeyZone>,
    val sourceSize: Long,
    val korfOffset: Long,
    val confidence: String,
    val notes: List<String> = emptyList()
)
