package com.milad.musicstudio.korg

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * KMP structural reader.
 *
 * Important: this is a compatibility/forensics parser, not a claim of a complete
 * proprietary KORG KMP decoder. Unknown fields are kept as candidates and the
 * UI labels heuristic mappings explicitly.
 */
object KmpParser {
    private val KORF = byteArrayOf('K'.code.toByte(),'O'.code.toByte(),'R'.code.toByte(),'F'.code.toByte())

    fun parse(file: File): KmpProgram {
        val b = file.readBytes()
        val korf = indexOf(b, KORF)
        if (korf < 0) return KmpProgram(file.nameWithoutExtension, emptyList(), b.size.toLong(), -1, "none", listOf("KORF signature not found"))

        val name = extractHeaderName(b, korf) ?: file.nameWithoutExtension
        val ints = candidateIntegers(b, korf + 24)
        val refs = ints.distinct().filter { it in 1..4096 }.take(32)

        // Safe fallback mapping: one full-range zone. It is deliberately marked heuristic.
        val root = 60
        val zone = KeyZone(0, 127, root, 1, 127, refs.firstOrNull(), "fallback")
        val notes = mutableListOf<String>()
        notes += "KORF @ $korf"
        notes += "Candidate integer references: ${refs.size}"
        if (refs.isNotEmpty()) notes += "First candidate sample reference: ${refs.first()}"
        notes += "Zone boundaries are fallback until exact KMP field offsets are validated against more KORG files."

        return KmpProgram(name, listOf(zone), b.size.toLong(), korf.toLong(), "structural", notes)
    }

    private fun extractHeaderName(b: ByteArray, korf: Int): String? {
        val start = (korf + 4).coerceAtLeast(0)
        val end = minOf(b.size, start + 96)
        var best: String? = null
        var i = start
        while (i < end) {
            if (b[i].toInt() in 32..126) {
                val s = i
                while (i < end && b[i].toInt() in 32..126) i++
                if (i - s >= 3) {
                    val v = b.copyOfRange(s, i).toString(Charsets.US_ASCII).trim()
                    if (v.any { it.isLetterOrDigit() }) best = v
                }
            } else i++
        }
        return best
    }

    private fun candidateIntegers(b: ByteArray, start: Int): List<Int> {
        val out = ArrayList<Int>()
        var p = start
        while (p + 4 <= b.size && out.size < 512) {
            val v = ByteBuffer.wrap(b, p, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (v in 1..4096) out += v
            p += 4
        }
        return out
    }

    private fun indexOf(a: ByteArray, p: ByteArray): Int {
        if (p.isEmpty() || a.size < p.size) return -1
        for (i in 0..a.size - p.size) {
            var ok = true
            for (j in p.indices) if (a[i + j] != p[j]) { ok = false; break }
            if (ok) return i
        }
        return -1
    }
}
