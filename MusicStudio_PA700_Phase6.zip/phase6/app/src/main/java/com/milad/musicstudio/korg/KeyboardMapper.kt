package com.milad.musicstudio.korg

class KeyboardMapper(private var program: KmpProgram? = null) {
    fun setProgram(p: KmpProgram) { program = p }
    fun zoneFor(note: Int, velocity: Int = 100): KeyZone? = program?.zones?.firstOrNull {
        note in it.lowKey..it.highKey && velocity in it.velocityLow..it.velocityHigh
    }
    fun rootFor(note: Int, velocity: Int = 100): Int? = zoneFor(note, velocity)?.rootKey
}
