# Music Studio PA700 — Phase 6

## Important build fix
This package is a **clean Gradle project root**. There is no nested `MusicStudio_PA700_Final/MusicStudio_PA700_Final` project directory.

The previous CI error:
`Directory '.../MusicStudio-PA700/MusicStudio-PA700' does not contain a Gradle build`
was caused by the CI working directory pointing one level too deep.

For GitHub Actions, build from the repository root:
`gradle assembleDebug`

A workflow is included under `.github/workflows/build.yml` and builds `app-debug.apk`.

## Phase 6 scope
- KMP structural parsing and zone model
- Keyboard zone lookup
- Experimental PCM probing/playback path
- Clean Gradle project layout and reproducible CI build

The KMP/PCM compatibility layer is still explicitly marked experimental where exact proprietary field/codec behavior has not been verified against sufficient reference files.
